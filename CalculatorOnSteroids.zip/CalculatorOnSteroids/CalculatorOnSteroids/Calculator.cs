﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Data.SQLite;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorOnSteroids
{

    public partial class Calculator : Form
    {
        public Calculator()
        {
            InitializeComponent();
        }

        public double intResult = 0;
        public string strOperator = string.Empty;
        public bool isOperated = false;
        public double intMemory = 0;
        public bool isCollapsed;
        public bool isEquals = false;
        public bool isPosNeg = false;
        string strOperation = string.Empty;
        ListBox lstboxMemory = new ListBox();
        DataAccess dataAccess = new DataAccess();
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtBoxNumbers.Text = "0";
            strOperation = "C";
            OperatorString(strOperation);
            strOperation = string.Empty;
            txtBoxOperations.Text = string.Empty;
        }

        private void btnClearTwo_Click(object sender, EventArgs e)
        {
            strOperation = "CE";
            OperatorString(strOperation);
            txtBoxNumbers.Text = "0";
            intResult = 0;
            txtBoxOperations.Text = string.Empty;
            strOperation = string.Empty;
        }

        private void btnDeleteDigit_Click(object sender, EventArgs e)
        {
            int intstringlength = txtBoxNumbers.Text.ToString().Length;

            txtBoxNumbers.Text.ToString().Remove(intstringlength-1,intstringlength);
        }

        public void Operations (string stroperator, double number)
        {
            switch(stroperator)
            {
                case "+":
                    txtBoxNumbers.Text =  (intResult + double.Parse(txtBoxNumbers.Text.ToString())).ToString();
                    break;
                case "-":
                    txtBoxNumbers.Text = (intResult - double.Parse(txtBoxNumbers.Text.ToString())).ToString();
                    break;
                case "*":
                    txtBoxNumbers.Text = (intResult * double.Parse(txtBoxNumbers.Text.ToString())).ToString();
                    break;
                case "/":
                    txtBoxNumbers.Text = (intResult / double.Parse(txtBoxNumbers.Text.ToString())).ToString();
                    break;
                default:
                    break;
            }
            intResult = double.Parse(txtBoxNumbers.Text.ToString());
        }

        private void btnEquals_Click(object sender, EventArgs e)
        {
            txtBoxOperations.Text = txtBoxOperations.Text +" "+ txtBoxNumbers.Text + " ";
            Operations(strOperator, intResult);
            txtBoxOperations.Text = txtBoxOperations.Text + " " + "=" + " " + txtBoxNumbers.Text;
            dataAccess.ExecuteQuery("insert into History (Hist_Action, Hist_Value) values ('" + strOperation +"/Equals" +"','" + txtBoxNumbers.Text + "')");
            intResult = 0;
            isOperated = true;
            strOperator = string.Empty;
            strOperation = string.Empty;
            isEquals = true;
        }
        private void btnNumber_Click(object sender, EventArgs e)
        {
            if ((txtBoxNumbers.Text == "0") || (isOperated))
            {
                txtBoxNumbers.Clear();
            }
            if (isEquals == true)
            {
                txtBoxOperations.Clear();
                isEquals = false;
            }
            Button btnNumber = (Button)sender;
            if(btnNumber.Text == ".")
            {
                if (!txtBoxNumbers.Text.Contains("."))
                {
                    txtBoxNumbers.Text = txtBoxNumbers.Text + btnNumber.Text;
                }
            }
            else
            {
                txtBoxNumbers.Text = txtBoxNumbers.Text + btnNumber.Text;
            }
            isOperated = false;
        }

        private void btnOperator_Click(object sender, EventArgs e)
        {
            Button btnOperator = (Button)sender;
            if (intResult != 0)
            {
                txtBoxOperations.Text = txtBoxOperations.Text + " " + txtBoxNumbers.Text + " ";
                Operations(strOperator, intResult);
                strOperator = btnOperator.Text;
                OperatorString(strOperator);
                txtBoxOperations.Text = txtBoxOperations.Text + strOperator;
                isOperated = true;
            }
            else
            {
                strOperator = btnOperator.Text;
                OperatorString(strOperator);
                txtBoxOperations.Text = txtBoxNumbers.Text + " " + strOperator;
                intResult = double.Parse(txtBoxNumbers.Text);
                isOperated = true;
            }

        }

        private void btnMemory_Click(object sender, EventArgs e)
        {
            Button btnSavedMemory = (Button)sender;

            switch (btnSavedMemory.Text)
            {
                case "MC":
                    intMemory = 0;
                    lstBoxMemory.Items.Clear();
                    break;
                case "MR":
                    if (intMemory == 0)
                    {
                        MessageBox.Show("Memory Empty");
                    }
                    else
                    {
                        lstBoxMemory.Items.Add(intMemory);
                    }
                    break;
                case "MS":
                    intMemory = double.Parse(txtBoxNumbers.Text);
                    lstBoxMemory.Items.Add(intMemory);
                    break;
                case "M+":
                    intMemory = intMemory + double.Parse(txtBoxNumbers.Text);
                    lstBoxMemory.Items.Add(intMemory);
                    break;
                case "M-":
                    intMemory = intMemory - double.Parse(txtBoxNumbers.Text);
                    lstBoxMemory.Items.Add(intMemory);
                    break;
                case "+/-":
                    if ((txtBoxNumbers.Text != "0") && (txtBoxNumbers.Text !=null))
                    {
                        if (isPosNeg == false)
                        {
                            txtBoxNumbers.Text = txtBoxNumbers.Text;
                            txtBoxNumbers.Text = "-" + txtBoxNumbers.Text;
                            isPosNeg = true;
                        }
                        else
                        {
                            txtBoxNumbers.Text = txtBoxNumbers.Text.Remove(0, 1);
                            isPosNeg = false;
                        }
                    }
                    break;
                default:
                    break;
            }
        }

        private void Calculator_Load(object sender, EventArgs e)
        {
            dataAccess.SetConnection();
            dataAccess.sqlConn.Open();
            dataAccess.sqlCmd = dataAccess.sqlConn.CreateCommand();
            string cmdText = "select * from History";
            dataAccess.DB = new SQLiteDataAdapter(cmdText, dataAccess.sqlConn);
            dataAccess.dataSet.Reset();
            dataAccess.DB.Fill(dataAccess.dataSet);
            dataAccess.dataTable = dataAccess.dataSet.Tables[0];
            dataGridView1.DataSource = dataAccess.dataTable;
            dataAccess.sqlConn.Close();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (isCollapsed)
            {
                pnlOperators.Height += 10;
                if (pnlOperators.Size == pnlOperators.MaximumSize)
                {
                    timer1.Stop();
                    isCollapsed = false;
                }
            }
            else
            {
                pnlOperators.Height -= 10;
                if (pnlOperators.Size == pnlOperators.MinimumSize)
                {
                    timer1.Stop();
                    isCollapsed = true;
                }
            }
        }

        private void btnDropDown_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void exportToTextToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TextWriter txtWriter = new StreamWriter(@".\Files\History.txt");
            int intRowCount = dataGridView1.Rows.Count;
            for (int i = 0; i < intRowCount - 1; i++)
            {
                txtWriter.WriteLine(dataGridView1.Rows[i].Cells[0].Value.ToString() + ","
                    +dataGridView1.Rows[i].Cells[1].Value.ToString() + ","
                    +dataGridView1.Rows[i].Cells[2].Value.ToString());
            }
            txtWriter.Close();
            MessageBox.Show("History Exported to 'Files' Folder!");
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            lstBoxMemory.Items.Clear();
            txtBoxNumbers.Text = "0";
            txtBoxOperations.Text = string.Empty;
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            History history = new History();
            history.Show();
        }
        public void OperatorString (string strCommand)
        {
            switch (strCommand)
            {
                case "+":
                    if (strOperation == string.Empty)
                    {
                        strOperation = "Add";
                    }
                    else
                    {
                        strOperation = strOperation + "/Add";
                    }
                    break;
                case "-":
                    if (strOperation == string.Empty)
                    {
                        strOperation = "Minus";
                    }
                    else
                    {
                        strOperation = strOperation + "/Minus";
                    }
                    break;
                case "*":
                    if (strOperation == string.Empty)
                    {
                        strOperation = "Multiply";
                    }
                    else
                    {
                        strOperation = strOperation + "/Multiply";
                    }
                    break;
                case "/":
                    if (strOperation == string.Empty)
                    {
                        strOperation = "Divide";
                    }
                    else
                    {
                        strOperation = strOperation + "/Divide";
                    }
                    break;
                case "=":
                    strOperation = strOperation + "/Equals";
                    break;
                case "CE":
                    strOperation = "Clear!";
                    dataAccess.ExecuteQuery("insert into History (Hist_Action, Hist_Value) values ('" + strOperation + "','" + (txtBoxNumbers.Text = "0") + "')");
                    break;
                case "C":
                    strOperation = "Clear!";
                    dataAccess.ExecuteQuery("insert into History (Hist_Action, Hist_Value) values ('" + strOperation + "','" + (txtBoxNumbers.Text = "0") + "')");
                    break;
                default:
                    break;
            }
        }

        private void importFromTextToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
    
}
