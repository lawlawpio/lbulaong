﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SQLite;
using System.Configuration;
using Dapper;

namespace CalculatorOnSteroids
{
    public class DataAccess
    {
        public SQLiteConnection sqlConn;
        public SQLiteCommand sqlCmd;
        public SQLiteDataAdapter DB;
        public DataSet dataSet = new DataSet();
        public DataTable dataTable = new DataTable();

        public void SetConnection()
        {
            string strConnectionString = ConfigurationManager.ConnectionStrings["HistoryDB"].ConnectionString;
            sqlConn = new SQLiteConnection(strConnectionString);
        }

        public void ExecuteQuery(string strQuery)
        {
            SetConnection();
            sqlConn.Open();
            sqlCmd = sqlConn.CreateCommand();
            sqlCmd.CommandText = strQuery;
            sqlCmd.ExecuteNonQuery();
            sqlConn.Close();
        }


    }
}
