﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SQLite;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CalculatorOnSteroids
{
    public partial class History : Form
    {
        DataAccess dataAccess = new DataAccess();

        public History()
        {
            InitializeComponent();
        }
        private void History_Load(object sender, EventArgs e)
        {
            ConnectDatagridView();
        }

        private void btnClearHistory_Click(object sender, EventArgs e)
        {
            dataAccess.ExecuteQuery("delete from History");
            ConnectDatagridView();
            gvHistory.Refresh();
            gvHistory.Update();
        }

        public void ConnectDatagridView()
        {
            dataAccess.SetConnection();
            dataAccess.sqlConn.Open();
            dataAccess.sqlCmd = dataAccess.sqlConn.CreateCommand();
            string cmdText = "select * from History";
            dataAccess.DB = new SQLiteDataAdapter(cmdText, dataAccess.sqlConn);
            dataAccess.dataSet.Reset();
            dataAccess.DB.Fill(dataAccess.dataSet);
            dataAccess.dataTable = dataAccess.dataSet.Tables[0];
            gvHistory.DataSource = dataAccess.dataTable;
            dataAccess.sqlConn.Close();
        }
    }
}
